from django.db import models

class Item(models.Model):
    iid = models.CharField(max_length=20)
    item_name = models.CharField(max_length=20)
    item_qty = models.CharField(max_length=10)
    item_total_price = models.CharField(max_length=30)
