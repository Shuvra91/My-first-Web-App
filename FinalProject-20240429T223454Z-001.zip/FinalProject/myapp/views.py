from django.shortcuts import render, redirect
from .models import Item
from .forms import ItemForm


def welcome(request):
    return render(request, "welcome.html")

def load_form(request):
    form = ItemForm
    return render(request, "index.html", {'form':form})

def add(request):
    form = ItemForm(request.POST)
    form.save()
    return redirect('/show')

def show(request):
    item = Item.objects.all
    return render(request, 'show.html', {'item': item})

def edit(request, id):
    item = Item.objects.get(id = id)
    return render(request, 'edit.html', {'item': item})

def update(request, id):
    item = Item.objects.get(id = id)
    form = ItemForm(request.POST, instance = item)
    form.save()
    return redirect('/show')

def delete(request, id):
    item = Item.objects.get(id=id)
    item.delete()
    return redirect('/show')




